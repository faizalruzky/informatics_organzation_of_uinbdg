UPDATE `#__extensions` SET `enabled` = '1' WHERE `name` = 'plg_editors-xtd_oziogallery';
